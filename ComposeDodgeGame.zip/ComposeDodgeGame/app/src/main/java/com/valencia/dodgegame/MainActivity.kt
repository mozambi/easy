package com.valencia.dodgegame

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.isActive
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalDensity
import kotlin.random.Random
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    Game()
                }
            }
        }
    }
}

private data class Rock(var x: Float, var y: Float, var size: Float, var speed: Float)

@Composable
fun Game() {
    var screenW by remember { mutableStateOf(0f) }
    var screenH by remember { mutableStateOf(0f) }

    var playerX by remember { mutableStateOf(0f) }
    val playerY by remember { mutableStateOf(0.85f) } // as fraction of height
    val playerSizePx = with(LocalDensity.current) { 36.dp.toPx() }

    var rocks by remember { mutableStateOf(listOf<Rock>()) }
    var score by remember { mutableStateOf(0) }
    var best by remember { mutableStateOf(0) }
    var running by remember { mutableStateOf(false) }
    var gameOver by remember { mutableStateOf(false) }

    LaunchedEffect(screenW, screenH, running) {
        if (screenW == 0f || screenH == 0f || !running) return@LaunchedEffect
        val rnd = Random(System.currentTimeMillis())
        // Initialize
        rocks = emptyList()
        score = 0
        gameOver = false
        // Loop
        while (isActive && running && !gameOver) {
            // Spawn rocks
            if (rocks.size < 6 && rnd.nextFloat() < 0.35f) {
                val size = (24 + rnd.nextInt(28)).toFloat()
                rocks = rocks + Rock(
                    x = rnd.nextFloat() * (screenW - size) + size/2,
                    y = -size,
                    size = size,
                    speed = (3 + rnd.nextInt(6)) * (screenH / 800f)
                )
            }
            // Move rocks
            rocks = rocks.map { r ->
                r.y += r.speed
                r
            }.filter { it.y - it.size/2 < screenH + 10 }

            // Collision check
            val px = playerX
            val py = playerY * screenH
            val pr = playerSizePx / 2f
            for (r in rocks) {
                val dx = (r.x - px)
                val dy = (r.y - py)
                val dist2 = dx*dx + dy*dy
                val rad = pr + r.size/2f
                if (dist2 <= rad*rad) {
                    gameOver = true
                    running = false
                    if (score > best) best = score
                    break
                }
            }

            // Scoring
            score += 1
            delay(16L) // ~60 fps
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF101218)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // HUD
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Best: $best", color = Color(0xFF8AB4F8), fontSize = 16.sp)
            Text("Score: $score", color = Color(0xFFBB86FC), fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        }

        // Game canvas
        Box(modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    // Tap left/right to move
                    val step = screenW * 0.12f
                    if (offset.x < size.width / 2) playerX -= step else playerX += step
                    // Clamp
                    playerX = playerX.coerceIn(playerSizePx/2, screenW - playerSizePx/2)
                }
            }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                screenW = size.width
                screenH = size.height
                if (playerX == 0f && screenW > 0f) playerX = screenW / 2f

                // Stars background (simple parallax dots)
                val rnd = Random(score)
                for (i in 0 until 60) {
                    val sx = rnd.nextFloat() * screenW
                    val sy = (rnd.nextFloat() * screenH + score % screenH)
                    drawCircle(Color(0x22FFFFFF), radius = 1.5f, center = Offset(sx, sy % screenH))
                }

                // Rocks
                rocks.forEach { r ->
                    drawCircle(Color(0xFFE57373), radius = r.size/2f, center = Offset(r.x, r.y))
                }

                // Player ship (triangle)
                val px = playerX
                val py = playerY * screenH
                val s = playerSizePx
                // triangle points
                val p1 = Offset(px, py - s/1.5f)
                val p2 = Offset(px - s/2f, py + s/2f)
                val p3 = Offset(px + s/2f, py + s/2f)
                drawIntoCanvas { canvas ->
                    val path = androidx.compose.ui.graphics.Path().apply {
                        moveTo(p1.x, p1.y); lineTo(p2.x, p2.y); lineTo(p3.x, p3.y); close()
                    }
                    canvas.drawPath(path, androidx.compose.ui.graphics.Paint().apply {
                        color = Color(0xFF64FFDA)
                    })
                }
            }

            if (!running) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0x66000000)),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        if (gameOver) "Game Over" else "Dodge Game",
                        color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold
                    )
                    if (gameOver) {
                        Text("Score: $score", color = Color(0xFFBBDEFB), fontSize = 20.sp, modifier = Modifier.padding(top = 8.dp))
                    }
                    Button(
                        onClick = {
                            // restart
                            rocks = emptyList()
                            score = 0
                            gameOver = false
                            running = true
                        },
                        modifier = Modifier.padding(top = 16.dp)
                    ) { Text(if (gameOver) "Retry" else "Start") }

                    Spacer(Modifier.height(12.dp))
                    Text("Tap left/right to move", color = Color(0xFFEEEEEE), fontSize = 14.sp)
                }
            }
        }

        // Footer
        Spacer(Modifier.height(8.dp))
    }
}