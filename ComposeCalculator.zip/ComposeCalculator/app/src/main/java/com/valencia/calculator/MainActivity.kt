package com.valencia.calculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import kotlin.math.round

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    CalculatorScreen()
                }
            }
        }
    }
}

@Composable
fun CalcButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, filled: Boolean = false) {
    val bg = if (filled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
    val fg = if (filled) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
    Button(
        onClick = onClick,
        modifier = modifier
            .height(64.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = bg, contentColor = fg),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
    ) {
        Text(text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun CalculatorScreen() {
    var display by remember { mutableStateOf("0") }
    var lastValue by remember { mutableStateOf<Double?>(null) }
    var lastOp by remember { mutableStateOf<String?>(null) }
    var justEvaluated by remember { mutableStateOf(false) }

    fun clearAll() {
        display = "0"
        lastValue = null
        lastOp = null
        justEvaluated = false
    }

    fun inputDigit(d: String) {
        if (justEvaluated) {
            display = "0"
            justEvaluated = false
        }
        display = if (display == "0" && d != ".") d
        else if (d == "." && display.contains(".")) display
        else display + d
    }

    fun applyOp(op: String) {
        try {
            val current = display.toDoubleOrNull() ?: 0.0
            if (lastValue == null) {
                lastValue = current
            } else if (lastOp != null) {
                lastValue = eval(lastValue!!, current, lastOp!!)
                display = trim(lastValue!!)
            }
            lastOp = op
            justEvaluated = true
        } catch (_: Exception) { /* ignore */ }
    }

    fun equals() {
        try {
            val current = display.toDoubleOrNull() ?: 0.0
            if (lastValue != null && lastOp != null) {
                val result = eval(lastValue!!, current, lastOp!!)
                display = trim(result)
                lastValue = null
                lastOp = null
                justEvaluated = true
            }
        } catch (_: Exception) { /* ignore */ }
    }

    fun backspace() {
        if (justEvaluated) return
        display = if (display.length <= 1) "0" else display.dropLast(1)
    }

    fun toggleSign() {
        if (display.startsWith("-")) display = display.drop(1) else if (display != "0") display = "-$display"
    }

    fun percent() {
        val current = display.toDoubleOrNull() ?: return
        display = trim(current / 100.0)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        Text(
            text = display,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(8.dp),
            textAlign = TextAlign.End,
            fontSize = 48.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                CalcButton("C", { clearAll() }, modifier = Modifier.weight(1f))
                CalcButton("⌫", { backspace() }, modifier = Modifier.weight(1f))
                CalcButton("+/−", { toggleSign() }, modifier = Modifier.weight(1f))
                CalcButton("%", { percent() }, modifier = Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                CalcButton("7", { inputDigit("7") }, modifier = Modifier.weight(1f))
                CalcButton("8", { inputDigit("8") }, modifier = Modifier.weight(1f))
                CalcButton("9", { inputDigit("9") }, modifier = Modifier.weight(1f))
                CalcButton("÷", { applyOp("÷") }, modifier = Modifier.weight(1f), filled = true)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                CalcButton("4", { inputDigit("4") }, modifier = Modifier.weight(1f))
                CalcButton("5", { inputDigit("5") }, modifier = Modifier.weight(1f))
                CalcButton("6", { inputDigit("6") }, modifier = Modifier.weight(1f))
                CalcButton("×", { applyOp("×") }, modifier = Modifier.weight(1f), filled = true)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                CalcButton("1", { inputDigit("1") }, modifier = Modifier.weight(1f))
                CalcButton("2", { inputDigit("2") }, modifier = Modifier.weight(1f))
                CalcButton("3", { inputDigit("3") }, modifier = Modifier.weight(1f))
                CalcButton("−", { applyOp("−") }, modifier = Modifier.weight(1f), filled = true)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                CalcButton("0", { inputDigit("0") }, modifier = Modifier.weight(2f))
                CalcButton(".", { inputDigit(".") }, modifier = Modifier.weight(1f))
                CalcButton("+", { applyOp("+") }, modifier = Modifier.weight(1f), filled = true)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                CalcButton("=", { equals() }, modifier = Modifier.weight(1f), filled = true)
            }
        }
    }
}

private fun eval(a: Double, b: Double, op: String): Double {
    return when (op) {
        "+" -> a + b
        "−" -> a - b
        "×" -> a * b
        "÷" -> if (b == 0.0) Double.NaN else a / b
        else -> b
    }
}

private fun trim(v: Double): String {
    if (v.isNaN() || v.isInfinite()) return "Error"
    val rounded = kotlin.math.round(v * 1_000_000.0) / 1_000_000.0
    val s = rounded.toString()
    return if (s.endsWith(".0")) s.dropLast(2) else s
}